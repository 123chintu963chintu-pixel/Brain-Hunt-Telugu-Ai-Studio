import { NextResponse } from "next/server";
import { getOwnerSession, clearOwnerSessionCookie } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const session = await getOwnerSession();

  if (session) {
    await prisma.auditLog.create({
      data: { action: "owner_logout", ownerId: session.ownerId },
    });
  }

  await clearOwnerSessionCookie();
  return NextResponse.json({ success: true });
}
