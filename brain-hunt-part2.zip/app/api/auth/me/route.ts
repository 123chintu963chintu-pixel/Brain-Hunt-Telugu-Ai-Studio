import { NextResponse } from "next/server";
import { getOwnerSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getOwnerSession();
  if (!session) {
    return NextResponse.json({ authenticated: false }, { status: 200 });
  }

  const owner = await prisma.owner.findUnique({
    where: { id: session.ownerId },
    select: { id: true, email: true, createdAt: true },
  });

  if (!owner) {
    return NextResponse.json({ authenticated: false }, { status: 200 });
  }

  return NextResponse.json({ authenticated: true, owner });
}
