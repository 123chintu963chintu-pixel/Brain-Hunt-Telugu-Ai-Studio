import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { hashPassword, createOwnerToken, setOwnerSessionCookie } from "@/lib/auth";

const setupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

// This route only works ONCE — if any Owner already exists, it refuses.
// Use it to bootstrap the first owner account after deploy, then it locks itself out.
export async function POST(req: NextRequest) {
  const existingCount = await prisma.owner.count();
  if (existingCount > 0) {
    return NextResponse.json(
      { error: "Setup already completed. Use /api/auth/login instead." },
      { status: 403 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = setupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const { email, password } = parsed.data;
  const passwordHash = await hashPassword(password);

  const owner = await prisma.owner.create({
    data: { email, passwordHash },
  });

  const token = await createOwnerToken(owner.id);
  await setOwnerSessionCookie(token);

  await prisma.auditLog.create({
    data: { action: "owner_setup_completed", ownerId: owner.id },
  });

  return NextResponse.json({ success: true, owner: { id: owner.id, email: owner.email } });
}

// Lets the frontend check whether setup is still needed, without exposing anything sensitive.
export async function GET() {
  const existingCount = await prisma.owner.count();
  return NextResponse.json({ setupRequired: existingCount === 0 });
}
