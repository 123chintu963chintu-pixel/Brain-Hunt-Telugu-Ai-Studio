-- Brain Hunt Telugu AI Studio — Part 2 migration
-- Run this ONCE in Supabase Dashboard → SQL Editor → New query → Run.
-- This matches prisma/schema.prisma exactly (Prisma's default cuid()/naming).

create extension if not exists "pgcrypto";

create table if not exists "Owner" (
  "id" text primary key default gen_random_uuid()::text,
  "email" text unique not null,
  "passwordHash" text not null,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now()
);

create table if not exists "ProviderConfig" (
  "id" text primary key default gen_random_uuid()::text,
  "name" text unique not null,
  "type" text not null,
  "apiKeyEnv" text not null,
  "isActive" boolean not null default true,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now()
);

create table if not exists "Generation" (
  "id" text primary key default gen_random_uuid()::text,
  "prompt" text not null,
  "resultUrl" text,
  "status" text not null default 'pending',
  "providerId" text not null references "ProviderConfig"("id"),
  "createdAt" timestamptz not null default now()
);

create table if not exists "AITool" (
  "id" text primary key default gen_random_uuid()::text,
  "name" text not null,
  "description" text,
  "config" jsonb,
  "createdAt" timestamptz not null default now(),
  "updatedAt" timestamptz not null default now()
);

create table if not exists "ThemeSetting" (
  "id" text primary key default gen_random_uuid()::text,
  "key" text unique not null,
  "value" text not null,
  "updatedAt" timestamptz not null default now()
);

create table if not exists "StorageFile" (
  "id" text primary key default gen_random_uuid()::text,
  "filePath" text not null,
  "fileType" text not null,
  "sizeBytes" integer,
  "generationId" text references "Generation"("id"),
  "createdAt" timestamptz not null default now()
);

create table if not exists "AuditLog" (
  "id" text primary key default gen_random_uuid()::text,
  "action" text not null,
  "ownerId" text not null references "Owner"("id"),
  "metadata" jsonb,
  "createdAt" timestamptz not null default now()
);

create table if not exists "RateLimitLog" (
  "id" text primary key default gen_random_uuid()::text,
  "key" text not null,
  "count" integer not null default 1,
  "windowAt" timestamptz not null default now()
);

create table if not exists "BackupRecord" (
  "id" text primary key default gen_random_uuid()::text,
  "fileName" text not null,
  "status" text not null default 'pending',
  "createdAt" timestamptz not null default now()
);

-- Helpful indexes
create index if not exists "Generation_providerId_idx" on "Generation"("providerId");
create index if not exists "StorageFile_generationId_idx" on "StorageFile"("generationId");
create index if not exists "AuditLog_ownerId_idx" on "AuditLog"("ownerId");
create index if not exists "RateLimitLog_key_windowAt_idx" on "RateLimitLog"("key", "windowAt");
